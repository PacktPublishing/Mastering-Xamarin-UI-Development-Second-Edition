﻿//
//  BookDatabase.cs
//  Book Database Class that will be used to handle performing of CRUD operations
//
//  Created by Steven F. Daniel on 02/08/2018.
//  Copyright © 2018 GENIESOFT STUDIOS. All rights reserved.
//
using System.Collections.Generic;
using System.Linq;
using BookLibrary.Models;
using SQLite;

namespace BookLibrary.Database
{
    public class BookDatabase : IBookDatabase
    {
        static object locker = new object();

        static SQLiteConnection conn;
        static BookDatabase database;

        /// <summary>
        /// Returns an instance of our BookDatabase class
        /// </summary>
        /// <value>The current BookDatabase class instance.</value> 
        public static BookDatabase Database => database;

        /// <summary>
        /// Create our Book Library Database tables.
        /// </summary>
        /// <param name="connection">Connection.</param>
        public static void CreateDatabase(SQLiteConnection connection)
        {
            conn = connection;

            // Create the tables within our Book Library Database
            conn.CreateTable<BookItem>();
            database = new BookDatabase();
        }

        /// <summary>
        /// Gets all of the book library items from our database.
        /// </summary>
        /// <returns>The items.</returns>
        public IEnumerable<BookItem> GetItems()
        {
            // Set a mutual-exclusive lock on our database, while 
            // retrieving items.
            lock (locker)
            {
                return conn.Table<BookItem>().ToList();
            }
        }

        /// <summary>
        /// Gets a specific book item from the database.
        /// </summary>
        /// <returns>The item.</returns>
        /// <param name="id">Identifier.</param>
        public BookItem GetItem(int id)
        {
            // Set a mutual-exclusive lock on our database, while 
            // retrieving the book item.
            lock (locker)
            {
                return conn.Table<BookItem>().FirstOrDefault(x => x.Id == id);
            }
        }

        /// <summary>
        /// Saves the book item currently being edited.
        /// </summary>
        /// <returns>The item.</returns>
        /// <param name="item">Item.</param>
        public int SaveItem(BookItem item)
        {
            // Set a mutual-exclusive lock on our database, while 
            // saving/updating our book item.
            lock (locker)
            {
                if (item.Id != 0)
                {
                    conn.Update(item);
                    return item.Id;
                }
                else
                {
                    return conn.Insert(item);
                }
            }
        }

        /// <summary>
        /// Deletes a specific book item from the database.
        /// </summary>
        /// <returns>The item.</returns>
        /// <param name="id">Identifier.</param>
        public int DeleteItem(int id)
        {
            // Set a mutual-exclusive lock on our database, while 
            // deleting our book item.
            lock (locker)
            {
                return conn.Delete<BookItem>(id);
            }
        }
    }
}