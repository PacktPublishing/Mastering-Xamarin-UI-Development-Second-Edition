﻿//
//  IBookDatabase.cs
//  Book Database Interface used by our Book Database Class
//
//  Created by Steven F. Daniel on 02/08/2018.
//  Copyright © 2018 GENIESOFT STUDIOS. All rights reserved.
//
using System.Collections.Generic;
using BookLibrary.Models;

namespace BookLibrary.Database
{
    public interface IBookDatabase
    {
        // Gets all of the book library items from our database.
        IEnumerable<BookItem> GetItems();

        // Gets a specific book item from the database.
        BookItem GetItem(int id);

        // Saves the book item currently being edited.
        int SaveItem(BookItem item);

        // Deletes a specific book item from the database.
        int DeleteItem(int id);
    }
}